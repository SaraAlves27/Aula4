package applivraria;

public class Livro {
    private String autor, titulo, isbn, genero;
    private float preco;
    
    public Livro(){}
    
    public Livro(String autor, String titulo, String isbn, String genero){
        this.autor = autor;
        this.titulo = titulo;
        this.isbn = isbn;
        this.genero = genero;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        if(preco > 0){
            this.preco = preco;
        }
    }
    
    public String exibir(){
        return "Título: " + titulo + " autor: " + autor +" genero: "+ genero +" preço: " + preco;
    }
}
