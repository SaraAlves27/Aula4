package applivraria;

import java.util.Scanner;

public class AppLivraria {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Livro livros[] = new Livro[3];
        Livro livro;
        int qtdeRomance=0, QtdePreco=0;
        float preco, valorTotal=0;
        
        for (int i = 0; i < livros.length; i++) {
            livro = new Livro();
            
            System.out.println("Digite o autor:");
            livro.setAutor(in.next());
            System.out.println("Digite o titulo:");
            livro.setTitulo(in.next());
            System.out.println("Digite o ISBN:");
            livro.setIsbn(in.next());
            System.out.println("Digite o genero:");
            livro.setGenero(in.next());
            System.out.println("Digite o preço:");
            livro.setPreco(in.nextFloat());
            
            livros[i] = livro ;
        }

        for (Livro l : livros) {
            
            if(l.getGenero().equalsIgnoreCase("Romance")){
                qtdeRomance++;
            }
            
            preco = l.getPreco();
            
            if(preco >= 10 && preco <= 50){
                QtdePreco++;
            }
            
            valorTotal += preco;
        }
        
        for (Livro l : livros) {
            System.out.println(l.exibir());
        }
        
        System.out.println("Livros de Romance: "+qtdeRomance);
        System.out.println("Livros entre R$10 e R$50: "+ QtdePreco);
        System.out.println("Valor Total: "+ valorTotal);
    }

}
